#' GSE175601 pheno
#'
#' sample group information
#'
#' @format A data frame with 6 rows and 2 variables:
#' @source \url{https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE175601}
"pheno_example"
