#' GSE175601 mRNA expression profile data
#'
#' Array
#'
#' @format A data frame with 34729 rows and 6 variables:
#' @source \url{https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE175601}
"exp_example"
