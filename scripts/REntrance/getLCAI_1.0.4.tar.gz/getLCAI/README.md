
# getLCAI

<!-- badges: start -->
<!-- badges: end -->

The goal of getLCAI is to calculate the Lung Cancer Aggressive Index (LCAI).

## Installation

You can install the development version of getLCAI like so:

``` r
install.packages("getLCAI")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(getLCAI)
data(exp_example)
data(pheno_example)

outlist = getlcai(exp = exp_example,
                  pheno = pheno_example,
                  control = "Control",
                  experimental = "experimental",
                  type = 'Array',
                  plotPCA = TRUE)
```

